package com.example.foodrecipeapp.Models;

public class Measures {
    public Us us;
    public Metric metric;
}
