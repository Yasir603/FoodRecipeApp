package com.example.foodrecipeapp.Listeners;

public interface RecipeClickListener {
    void onRexipeClicked(String id);

}
