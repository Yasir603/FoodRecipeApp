package com.example.foodrecipeapp.Listeners;

import com.example.foodrecipeapp.Models.RandomRecipeApiResponse;

public abstract class RandomRecipeResponseListener {
    public abstract void didFetch(RandomRecipeApiResponse response, String message);
    public abstract void didError(String message);

}
