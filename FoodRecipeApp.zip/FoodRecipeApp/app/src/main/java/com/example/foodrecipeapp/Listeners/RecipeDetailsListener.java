package com.example.foodrecipeapp.Listeners;

import com.example.foodrecipeapp.Models.RecipeDetailsResponce;

public interface RecipeDetailsListener {
    void didFetch(RecipeDetailsResponce responce, String message);
    void didError(String message);
}
